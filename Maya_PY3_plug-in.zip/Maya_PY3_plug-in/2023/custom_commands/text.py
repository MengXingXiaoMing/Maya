#coding=gbk
import os
import inspect
print('����һ��py����')
file_path = os.path.join('/'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
print(file_path)
if 'self_open_file' in globals():
    if self_open_file:
        file_path = self_open_file
        self_open_file = []
        print(file_path)