# -*- coding: utf-8 -*-
import random
import maya.mel as mel
import maya.cmds as cmds
# 获取文件路径
import os
import sys
import inspect
import importlib

# 文件路径
file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
# 根路径
root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
# 版本号
maya_version = cmds.about(version=True)
# 库路径
library_path = root_path + '\\' + maya_version
# 库添加到系统路径
sys.path.append(library_path)

class Common:
    def __init__(self):
        # 文件路径
        self.file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
        # 根路径
        self.root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-2]))
        # 版本号
        self.maya_version = cmds.about(version=True)
    # 加载对应后缀文件名称并返回
    def load_file_fame_of_the_corresponding_suffix(self, file_path, have_suffix, *all_suffix):
        files = os.listdir(file_path)  # 获取文件夹下所有文件名称
        Out = []
        for suffix in all_suffix:
            for file in files:
                if not os.path.splitext(file)[1]:
                    continue
                if file == '__init__.py':
                    continue
                if os.path.splitext(file)[1] in suffix:  # 找到指定后缀的文件
                    if (have_suffix > 0):
                        Out.append(file)  # 将元素添加到列表最后
                    else:
                        Out.append(os.path.splitext(file)[0])  # 将元素添加到列表最后
        return (Out)
    #运行对应命令,括号内为完整路径
    def run_corresponding_command(self,file_path):
        FileName = file_path.split('/')
        Name = FileName[len(FileName)-1].split('.')
        if Name[1]=='mel':
            mel.eval('source ('+file_path+');')
        if Name[1]=='py':
            import maya.app.general.executeDroppedPythonFile as myTempEDPF
            myTempEDPF.executeDroppedPythonFile(file_path, "")
            del myTempEDPF

    # 导入导出文件
    def import_export_file(self,name, import_additional_path, imp_exp_file,file_type):
        #name = cmds.optionMenu(ImportFileName, q=1, value=1)

        suffix = ''
        if file_type == 'mayaAscii':
            suffix = '.ma'
        if file_type == 'mayaBinary':
            suffix = '.mb'
        print('performFileDropAction  ("' + import_additional_path + '/' + name + suffix + '");')
        if imp_exp_file == 1:  # 导入
            cmds.file(import_additional_path + '/' + name + suffix,
                pr=1, ignoreVersion=1, i=1, type=file_type, importFrameRate=True, namespace=":",
                importTimeRange="override", ra=True, mergeNamespacesOnClash=True, options="v=0;")
            # mel.eval('performFileDropAction  ("' + import_additional_path + '/' + name + suffix+'");')
        else:  # mayaAscii#mayaBinary#导出
            cmds.file((import_additional_path + '/' + name + suffix), pr=1, typ=file_type, force=1,
                         options="v=0;", es=1)
