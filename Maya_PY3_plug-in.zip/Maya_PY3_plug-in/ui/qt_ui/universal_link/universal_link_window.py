# -*- coding: utf-8 -*-
import inspect
import os

from PySide2 import QtWidgets, QtCore, QtGui
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtCore import *
import maya.OpenMayaUI as Omui
from shiboken2 import wrapInstance
import maya.cmds as cmds

import inspect
import importlib

import ui_edit
from ui_edit import *
importlib.reload(ui_edit)

import maya_common
from maya_common import *
importlib.reload(maya_common)

class Window(QtWidgets.QMainWindow):
    def __init__(self, parent=wrapInstance(int(Omui.MQtUtil.mainWindow()), QtWidgets.QWidget)):
        try:
            window.close()
            window.deleteLater()
        except:
            pass
        super(Window, self).__init__(parent)
        self.maya_version = cmds.about(version=True)
        self.setWindowTitle('通用链接器(Maya'+self.maya_version+')')
        self.ui_edit = UiEdit()
        self.maya_common = MayaCommon()

        self.create_widgets()
        self.create_layouts()
        self.create_connect()

        # 文件路径
        self.file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
        # 根路径
        self.root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
        # 版本号
        self.maya_version = cmds.about(version=True)
        # 库路径
        self.library_path = self.root_path + '\\' + self.maya_version
    def create_widgets(self):
        # 第一行
        self.label_1 = QtWidgets.QLabel('源')
        self.comboBox_1 = QtWidgets.QComboBox()
        self.comboBox_1.addItems(['后期', '交互'])

        self.splitter_1 = QtWidgets.QSplitter()
        self.splitter_1.setOrientation(Qt.Vertical)
        self.splitter_1.setFixedWidth(1)
        self.splitter_1.setFrameStyle(1)

        self.label_2 = QtWidgets.QLabel('数值映射')
        self.comboBox_2 = QtWidgets.QComboBox()
        self.comboBox_2.addItems(['后期', '交互'])

        self.splitter_2 = QtWidgets.QSplitter()
        self.splitter_2.setOrientation(Qt.Vertical)
        self.splitter_2.setFixedWidth(1)
        self.splitter_2.setFrameStyle(1)

        self.label_3 = QtWidgets.QLabel('目标')
        self.comboBox_3 = QtWidgets.QComboBox()
        self.comboBox_3.addItems(['后期', '交互'])

        self.label_4 = QtWidgets.QLabel('源')
        self.label_5 = QtWidgets.QLabel('源')
        self.label_6 = QtWidgets.QLabel('源')

        self.button_1 = QtWidgets.QPushButton('链接（如果目标或者源缺失则跳过那项）')







    def create_layouts(self):
        self.central_widget = QtWidgets.QWidget(self)
        self.setCentralWidget(self.central_widget)

        main_layout = QtWidgets.QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(1)

        # 第一行
        h_Box_layout_1 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_1)

        v_Box_layout_1 = QtWidgets.QVBoxLayout()
        h_Box_layout_1.addLayout(v_Box_layout_1)
        v_Box_layout_1.addWidget(self.label_1)
        v_Box_layout_1.addWidget(self.comboBox_1)

        h_Box_layout_1.addWidget(self.splitter_1)

        v_Box_layout_2 = QtWidgets.QVBoxLayout()
        h_Box_layout_1.addLayout(v_Box_layout_2)
        v_Box_layout_2.addWidget(self.label_2)
        v_Box_layout_2.addWidget(self.comboBox_2)

        h_Box_layout_1.addWidget(self.splitter_2)

        v_Box_layout_3 = QtWidgets.QVBoxLayout()
        h_Box_layout_1.addLayout(v_Box_layout_3)
        v_Box_layout_3.addWidget(self.label_3)
        v_Box_layout_3.addWidget(self.comboBox_3)

        h_Box_layout_1.addStretch(1)

        h_Box_layout_3 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_3)

        self.v_Box_layout_4 = QtWidgets.QVBoxLayout()
        v_Box_layout_1.addLayout(self.v_Box_layout_4)
        self.v_Box_layout_4.addWidget(self.label_4)

        self.v_Box_layout_5 = QtWidgets.QVBoxLayout()
        v_Box_layout_2.addLayout(self.v_Box_layout_5)
        self.v_Box_layout_5.addWidget(self.label_5)

        self.v_Box_layout_6 = QtWidgets.QVBoxLayout()
        v_Box_layout_3.addLayout(self.v_Box_layout_6)
        self.v_Box_layout_6.addWidget(self.label_6)

        main_layout.addWidget(self.button_1)
        main_layout.addStretch(1)
    def create_connect(self):
        pass

    # 读取文件
    def read_file(self,file):
        soure, value_map, target = [],[],[]
        return soure, value_map, target
window = Window()
if __name__ == '__main__':
    window.show()
