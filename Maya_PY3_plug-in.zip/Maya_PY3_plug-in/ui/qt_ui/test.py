#coding=gbk
import importlib

import maya.cmds as cmds
import maya.mel as mel
# ��ȡ�ļ�·��
import os
import sys
import inspect
import webbrowser
# �ļ�·��
file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
# ��·��
root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
# �汾��
maya_version = cmds.about(version=True)
# ��·��
library_path = root_path + '\\' + maya_version

# �����ӵ�ϵͳ·��
sys.path.append(library_path)


sel_f = cmds.ls(sl=1,fl=1)

cmds.symmetricModelling("obiettivo_Mesh.e[23558]", e=1, ts=True)
cmds.blendShape("blendShape1.obiettivo_Mesh1", ss=0, md=1, sa="x", e=1, mt=(0, 0))


transmit_source = ['bace_bs_Mesh']
transmit_target = ['obiettivo_Mesh']
intermediate_state = ['Wrap4D_Mesh']

cmds.select(intermediate_state, transmit_source)
cmds.Morph(mmd=5)
cmds.select(intermediate_state, transmit_source, d=1)
morph = cmds.ls(sl=1)
# cmds.setAttr(morph[0] + '.morphMode', 3)
cmds.setAttr(morph[0] + '.neighborLevel', 10)

cmds.select(transmit_target, r=1)
cmds.duplicate(rr=1)
cmds.rename(cmds.ls(sl=1), transmit_target + "_Copy")
cmds.transferAttributes(intermediate_state, (transmit_target + "_Copy"), flipUVs=0, transferPositions=1,
                        transferUVs=0, sourceUvSpace="map1", searchMethod=3,
                        transferNormals=1, transferColors=0, targetUvSpace="map1", colorBorders=1,
                        sampleSpace=3)
cmds.select((transmit_target + "_Copy"), r=1)
cmds.duplicate(rr=1)
cmds.rename(cmds.ls(sl=1), transmit_target + "_CopySecond")
cmds.blendShape((transmit_target + "_Copy"), (transmit_target + "_CopySecond"), transmit_target,
                n="SecondPass_BS")
cmds.setAttr(("SecondPass_BS." + transmit_target + "_Copy"), 1)
cmds.setAttr(("SecondPass_BS." + transmit_target + "_CopySecond"), -1)
cmds.delete(transmit_target + "_CopySecond")
cmds.setAttr((transmit_source + ".visibility"), 0)
cmds.setAttr((intermediate_state + ".visibility"), 0)
cmds.setAttr((transmit_target + "_Copy.visibility"), 0)