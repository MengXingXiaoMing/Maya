#coding=gbk
import importlib

import maya.cmds as cmds
import maya.mel as mel
# ��ȡ�ļ�·��
import os
import sys
import inspect
import webbrowser
# �ļ�·��
file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
# ��·��
root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
# �汾��
maya_version = cmds.about(version=True)
# ��·��
library_path = root_path + '\\' + maya_version

# �����ӵ�ϵͳ·��
sys.path.append(library_path)


sel_f = cmds.ls(sl=1,fl=1)
p
cmds.symmetricModelling("obiettivo_Mesh.e[23558]", e=1, ts=True)
cmds.blendShape("blendShape1.obiettivo_Mesh1", ss=0, md=1, sa="x", e=1, mt=(0, 0))