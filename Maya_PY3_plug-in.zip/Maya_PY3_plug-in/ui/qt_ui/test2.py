#coding=gbk
import importlib

import maya.cmds as cmds
import maya.mel as mel
# ��ȡ�ļ�·��
import os
import sys
import inspect
import webbrowser
# �ļ�·��
file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
# ��·��
root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
# �汾��
maya_version = cmds.about(version=True)
# ��·��
library_path = root_path + '\\' + maya_version

# �����ӵ�ϵͳ·��
sys.path.append(library_path)


sel_f = cmds.ls(sl=1,fl=1)
for f in sel_f:
    mesh = sel_f[0].split('.')[0]
    cmds.select(mesh)
    mesh = cmds.ls(sl=1)
    copy_mesh = cmds.duplicate(mesh)

    cmds.setAttr(mesh[0]+'.rotatePivot', 0,0,0)
    cmds.setAttr(mesh[0]+'.scalePivot', 0,0,0)
    cmds.select(mesh[0]+'.f[*]')
    cmds.scale(1e-05, 0, 0, r=1, ws=1)

    blendShape = cmds.blendShape(copy_mesh, mesh)

    cmds.setAttr(blendShape[0]+'.'+copy_mesh[0], 1)
    cmds.symmetricModelling(f, e=1, ts=True)
    cmds.select(f)
    cmds.blendShape(blendShape[0]+'.'+copy_mesh[0], ss=0, md=1, sa="x", e=1, mt=(0, 0))
    cmds.select(mesh)
    cmds.DeleteHistory()
    cmds.delete(copy_mesh)
    cmds.symmetricModelling(s=0)

import pymel as pm
sel_f = cmds.ls(sl=1,fl=1)
mesh = [sel_f[0].split('.')[0]]
point = cmds.ls(mesh[0]+'.vtx[*]',fl=1)
r_point = []
for p in point:
    pos = cmds.xform(p, q=1, ws=1, t=1)
    if pos[0] < 0.001:
        r_point.append(p)
str_r_point = str(r_point)[1:-2]
new_s = str_r_point.replace("'", "\"")
for f in sel_f:
    cmds.select(f)
    common = ('activateTopoSymmetry("'+f+'", {'+new_s+'"}, {"'+mesh[0]+'"}, "facet", "dR_symmetrize", 1);')
    mel.eval(common)
cmds.select(cl=1)


# ��ȡMaya�������汾��Ϣ
full_version_string = cmds.about(iv=True)

# ��ӡ�����汾��Ϣ
print("Maya�������汾��Ϣ:", full_version_string[14:])




cone = cmds.cone(esw=360, ch=0, d=3, hr=2, ut=0, ssw=0, p=(0, -1, 0), s=8, r=1, tol=0.01, nsp=1, ax=(0, 1, 0))
# print(cone)
cmds.rebuildSurface("nurbsCone1", rt=0, kc=0, fr=0, ch=0, end=1, sv=4, su=4, kr=0, dir=2, kcp=1, tol=0.01, dv=3, du=3, rpo=1)
cmds.setAttr(cone[0]+'.scaleX', 10)
cmds.setAttr(cone[0]+'.scaleY', 10)
cmds.setAttr(cone[0]+'.scaleZ', 10)
# cmds.makeIdentity(cone,n=0, s=1, r=1, t=1, apply=True, pn=1)
cluster = cmds.cluster(cone)
# print(cluster)
cmds.setAttr(cluster[1]+'.rotatePivot', 0, 0, 0)
cmds.setAttr(cluster[1]+'.scalePivot', 0, 0, 0)
sphere = cmds.sphere(esw=360, ch=0, d=3, ut=0, ssw=0, p=(0, 0, 0), s=8, r=1, tol=0.01, nsp=4, ax=(0, 1, 0))
# print(sphere)
new_surface = cmds.nurbsBoolean('nurbsCone1', 'nurbsSphere1', ch=1, nsf=1, op=2)
cmds.setAttr(new_surface[0]+'.template', 1)
# print(new_surface)
grp_1 = cmds.group(sphere,cluster)
cmds.setAttr(grp_1 + '.visibility', 0)
grp_2 = cmds.group(cone,grp_1)

ls_loc = cmds.spaceLocator(p=(0, 0, 0))
cmds.setAttr(ls_loc[0]+'.translateX', -10)
cmds.setAttr(ls_loc[0]+'.translateY', -20)

shape = cmds.listRelatives(cone, s=1)
TypeNurbs = cmds.ls(shape[0], type='nurbsSurface')
cpom = cmds.createNode('closestPointOnSurface')
cmds.connectAttr((shape[0] + '.worldSpace[0]'), (cpom + '.inputSurface'), f=1)

pos = cmds.xform(ls_loc[0], q=1, a=1, ws=1, t=1)
cmds.setAttr((cpom + '.inPositionX'), pos[0])
cmds.setAttr((cpom + '.inPositionY'), pos[1])
cmds.setAttr((cpom + '.inPositionZ'), pos[2])
u = float(cmds.getAttr(cpom + ".parameterU"))
v = float(cmds.getAttr(cpom + ".parameterV"))
follicleShape = (ls_loc[0] + '_follicleShape')
follicle = (ls_loc[0] + '_follicle')
cmds.createNode('follicle', n=(ls_loc[0] + "_follicleShape"))
shape = cmds.listRelatives(cone, s=1, type='nurbsSurface')
cmds.connectAttr((shape[0] + '.worldSpace[0]'), (follicleShape + '.inputSurface'), f=1)
cmds.connectAttr((shape[0] + '.worldMatrix[0]'), (follicleShape + '.inputWorldMatrix'),f=1)
cmds.connectAttr((follicleShape + ".outTranslate"), (follicle + ".translate"),f=1)
# cmds.connectAttr((follicleShape + ".outRotate"), (follicle + ".rotate"), f=1)
cmds.setAttr((follicleShape + ".parameterU"), u)
cmds.setAttr((follicleShape + ".parameterV"), v)

cmds.setAttr(follicle + '.visibility', 0)

cmds.delete(cpom)

cmds.delete(ls_loc)

ls_loc = cmds.spaceLocator(p=(0, 0, 0))
cmds.setAttr(ls_loc[0]+ '.translateY', -1)
cmds.setAttr(ls_loc[0]+ '.visibility', 0)

move_grp = cmds.group(em=1)
cmds.parent(ls_loc, new_surface[0], follicle, move_grp)
curve = cmds.curve(p=[(0.0, 0.0, 0.0), (1.3246660753366768e-16, -1.0151220316349963, 0.0), (0.0399518620411479, -1.0205214288941349, 0.0), (0.07719707184685853, -1.03594916120812, 0.0), (0.1092661723850182, -1.0603803444126723, 0.0), (0.13369754874488846, -1.0924495608444404, 0.0), (0.14912501063975567, -1.1296946933878147, 0.0), (0.15452572135840073, -1.169646602968543, 0.0), (0.0, -1.1696465940573089, 0.0), (1.3246660753366768e-16, -1.0151220316349963, 0.0), (-0.0399518620411479, -1.0205214288941349, 0.0), (-0.07719707184685853, -1.03594916120812, 0.0), (-0.1092661723850182, -1.0603803444126723, 0.0), (-0.13369754874488846, -1.0924495608444404, 0.0), (-0.14912501063975567, -1.1296946933878147, 0.0), (-0.15452572135840073, -1.169646602968543, 0.0), (-0.14912501063975567, -1.2095984560975157, 0.0), (-0.13369754874488846, -1.24684366590469, 0.0), (-0.1092661723850182, -1.2789127664433722, 0.0), (-0.07719707184685853, -1.3033441428048105, 0.0), (-0.0399518620411479, -1.3187716046981095, 0.0), (1.7031435161511713e-16, -1.3241723154157095, 0.0), (0.0399518620411479, -1.3187716046981095, 0.0), (0.07719707184685853, -1.3033441428048105, 0.0), (0.1092661723850182, -1.2789127664433722, 0.0), (0.13369754874488846, -1.24684366590469, 0.0), (0.14912501063975567, -1.2095984560975157, 0.0), (0.15452572135840073, -1.169646602968543, 0.0), (-0.15452572135840073, -1.169646602968543, 0.0), (0.0, -1.1696465940573089, 0.0), (1.7031435161511713e-16, -1.3241723154157095, 0.0)], k=[0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0, 11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0, 21.0, 22.0, 23.0, 24.0, 25.0, 26.0, 27.0, 28.0, 29.0, 30.0], d=1)
cmds.setAttr((curve + '.tx'), lock=1)
cmds.setAttr((curve + '.ty'), lock=1)
cmds.setAttr((curve + '.tz'), lock=1)
cmds.connectAttr((curve + '.scaleX'), (curve + '.scaleY'),f=1)
cmds.connectAttr((curve + '.scaleX'), (curve + '.scaleZ'),f=1)
cmds.addAttr(curve, ln='range', min=-10, max=10, dv=1, at='double')
cmds.setAttr((curve + '.range'), e=1, keyable=True)
cmds.connectAttr((curve + '.range'), (cluster[1] + '.scaleY'),f=1)
cmds.addAttr(curve, ln='num', dv=1, at='double')
cmds.setAttr((curve + '.num'), e=1, keyable=True)
grp_3 = cmds.group(em=1)
cmds.parent(curve, grp_3)
cmds.parent(grp_3, grp_2)
cmds.parent(move_grp, curve)

vectorProduct = cmds.createNode('vectorProduct')
cmds.setAttr(vectorProduct + '.input1Y', -1)
cmds.connectAttr((follicle + '.translate'), (vectorProduct + '.input2'),f=1)
cmds.setAttr(vectorProduct + '.normalizeOutput', 1)

vectorProduct_2 = cmds.createNode('vectorProduct')
cmds.setAttr(vectorProduct_2 + '.input1Y', -1)
cmds.connectAttr((ls_loc[0] + '.translate'), (vectorProduct_2 + '.input2'),f=1)
cmds.setAttr(vectorProduct_2 + '.normalizeOutput', 1)

setRange = cmds.createNode('setRange')
cmds.setAttr(setRange + '.maxX', 1)
cmds.setAttr(setRange + '.oldMaxX', 1)
cmds.connectAttr((vectorProduct + '.outputX'), (setRange + '.oldMinX'),f=1)
cmds.connectAttr((vectorProduct_2 + '.outputX'), (setRange + '.valueX'),f=1)

cmds.connectAttr((setRange + '.outValueX'), (curve + '.num'),f=1)





