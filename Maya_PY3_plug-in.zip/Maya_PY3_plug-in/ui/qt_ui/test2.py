#coding=gbk
import importlib

import maya.cmds as cmds
import maya.mel as mel
# ��ȡ�ļ�·��
import os
import sys
import inspect
import webbrowser
# �ļ�·��
file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
# ��·��
root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
# �汾��
maya_version = cmds.about(version=True)
# ��·��
library_path = root_path + '\\' + maya_version

# �����ӵ�ϵͳ·��
sys.path.append(library_path)


sel_f = cmds.ls(sl=1,fl=1)
for f in sel_f:
    mesh = sel_f[0].split('.')[0]
    cmds.select(mesh)
    mesh = cmds.ls(sl=1)
    copy_mesh = cmds.duplicate(mesh)

    cmds.setAttr(mesh[0]+'.rotatePivot', 0,0,0)
    cmds.setAttr(mesh[0]+'.scalePivot', 0,0,0)
    cmds.select(mesh[0]+'.f[*]')
    cmds.scale(1e-05, 0, 0, r=1, ws=1)

    blendShape = cmds.blendShape(copy_mesh, mesh)

    cmds.setAttr(blendShape[0]+'.'+copy_mesh[0], 1)
    cmds.symmetricModelling(f, e=1, ts=True)
    cmds.select(f)
    cmds.blendShape(blendShape[0]+'.'+copy_mesh[0], ss=0, md=1, sa="x", e=1, mt=(0, 0))
    cmds.select(mesh)
    cmds.DeleteHistory()
    cmds.delete(copy_mesh)
    cmds.symmetricModelling(s=0)

import pymel as pm
sel_f = cmds.ls(sl=1,fl=1)
mesh = [sel_f[0].split('.')[0]]
point = cmds.ls(mesh[0]+'.vtx[*]',fl=1)
r_point = []
for p in point:
    pos = cmds.xform(p, q=1, ws=1, t=1)
    if pos[0] < 0.001:
        r_point.append(p)
str_r_point = str(r_point)[1:-2]
new_s = str_r_point.replace("'", "\"")
for f in sel_f:
    cmds.select(f)
    common = ('activateTopoSymmetry("'+f+'", {'+new_s+'"}, {"'+mesh[0]+'"}, "facet", "dR_symmetrize", 1);')
    mel.eval(common)
cmds.select(cl=1)


# ��ȡMaya�������汾��Ϣ
full_version_string = cmds.about(iv=True)

# ��ӡ�����汾��Ϣ
print("Maya�������汾��Ϣ:", full_version_string[14:])




cone = cmds.cone(esw=360, ch=0, d=3, hr=2, ut=0, ssw=0, p=(0, -1, 0), s=8, r=1, tol=0.01, nsp=1, ax=(0, 1, 0))
print(cone)
cmds.rebuildSurface("nurbsCone1", rt=0, kc=0, fr=0, ch=0, end=1, sv=4, su=4, kr=0, dir=2, kcp=1, tol=0.01, dv=3, du=3, rpo=1)
cmds.setAttr(cone[0]+'.scaleX', 10)
cmds.setAttr(cone[0]+'.scaleY', 10)
cmds.setAttr(cone[0]+'.scaleZ', 10)
cmds.makeIdentity(cone,n=0, s=1, r=1, t=1, apply=True, pn=1)
cluster = cmds.cluster(cone)
print(cluster)
cmds.setAttr(cluster[1]+'.rotatePivot', 0, 0, 0)
cmds.setAttr(cluster[1]+'.scalePivot', 0, 0, 0)
sphere = cmds.sphere(esw=360, ch=0, d=3, ut=0, ssw=0, p=(0, 0, 0), s=8, r=1, tol=0.01, nsp=4, ax=(0, 1, 0))
print(sphere)
cmds.nurbsBoolean('nurbsCone1', 'nurbsSphere1', ch=1, nsf=1, op=2)
grp_1 = cmds.group(sphere,cluster)
cmds.group(cone,grp_1)

ls_loc = cmds.spaceLocator(p=(0, 0, 0))
cmds.setAttr(ls_loc[0]+'.translateX', -10)
cmds.setAttr(ls_loc[0]+'.translateY', -20)

