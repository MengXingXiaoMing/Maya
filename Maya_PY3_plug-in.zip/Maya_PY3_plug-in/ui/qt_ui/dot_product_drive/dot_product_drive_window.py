# -*- coding: utf-8 -*-
import inspect
import os

from PySide2 import QtWidgets, QtCore, QtGui
from PySide2.QtGui import *
from PySide2.QtWidgets import *
from PySide2.QtCore import *
import maya.OpenMayaUI as Omui
from shiboken2 import wrapInstance
import maya.cmds as cmds





class Window(QtWidgets.QMainWindow):
    def __init__(self, parent=wrapInstance(int(Omui.MQtUtil.mainWindow()), QtWidgets.QWidget)):
        try:
            window.close()
            window.deleteLater()
        except:
            pass
        super(Window, self).__init__(parent)
        self.maya_version = cmds.about(version=True)
        self.setWindowTitle('点积驱动(Maya'+self.maya_version+')')
        self.create_widgets()
        self.create_layouts()
        self.create_connect()

        # 文件路径
        self.file_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-1]))
        # 根路径
        self.root_path = os.path.join('\\'.join(os.path.abspath(inspect.getsourcefile(lambda: 0)).split('\\')[:-4]))
        # 版本号
        self.maya_version = cmds.about(version=True)
        # 库路径
        self.library_path = self.root_path + '\\' + self.maya_version
    def create_widgets(self):
        # 第一行
        self.button_1 = QtWidgets.QPushButton('选择拷贝源')

        self.line_edit_1 = QtWidgets.QLineEdit()
        self.button_2 = QtWidgets.QPushButton('加载')

        self.button_3 = QtWidgets.QPushButton('选择拷贝点')
        self.line_edit_2 = QtWidgets.QLineEdit()
        self.button_4 = QtWidgets.QPushButton('加载')

        self.button_5 = QtWidgets.QPushButton('拷贝点权重')

        self.splitter_1 = QtWidgets.QSplitter()
        self.splitter_1.setFixedHeight(1)
        self.splitter_1.setFrameStyle(1)

        # 第二行
        self.button_6 = QtWidgets.QPushButton('移除无权重骨骼')
        self.button_7 = QtWidgets.QPushButton('统一循环边权重')
        self.button_8 = QtWidgets.QPushButton('中线建立骨骼链')

        self.button_9 = QtWidgets.QPushButton(self)
        self.button_9.setFixedSize(50, 50)
        if QtCore.QResource(':/paintSkinWeights.png').isValid():
            i = QtGui.QIcon(':/paintSkinWeights.png')
            self.button_9.setIcon(i)
        self.button_9.setIconSize(QSize(50, 50))
        self.button_10 = QtWidgets.QPushButton(self)
        self.button_10.setFixedSize(50, 50)
        if QtCore.QResource(':/weightHammer.png').isValid():
            i = QtGui.QIcon(':/weightHammer.png')
            self.button_10.setIcon(i)
        self.button_10.setIconSize(QSize(50, 50))
        self.button_11 = QtWidgets.QPushButton(self)
        self.button_11.setFixedSize(50, 50)
        if QtCore.QResource(':/copySkinWeight.png').isValid():
            i = QtGui.QIcon(':/copySkinWeight.png')
            self.button_11.setIcon(i)
        self.button_11.setIconSize(QSize(50, 50))
        self.button_12 = QtWidgets.QPushButton(self)
        self.button_12.setFixedSize(50, 50)
        if QtCore.QResource(':/mirrorSkinWeight.png').isValid():
            i = QtGui.QIcon(':/mirrorSkinWeight.png')
            self.button_12.setIcon(i)
        self.button_12.setIconSize(QSize(50, 50))
        self.button_13 = QtWidgets.QPushButton(self)
        self.button_13.setFixedSize(50, 50)
        if QtCore.QResource(':/moveSkinnedJoint.png').isValid():
            i = QtGui.QIcon(':/moveSkinnedJoint.png')
            self.button_13.setIcon(i)
        self.button_13.setIconSize(QSize(50, 50))
        self.button_14 = QtWidgets.QPushButton(self)
        self.button_14.setFixedSize(50, 50)
        if QtCore.QResource(':/clearCanvas.png').isValid():
            i = QtGui.QIcon(':/clearCanvas.png')
            self.button_14.setIcon(i)
        self.button_14.setIconSize(QSize(50, 50))
        self.button_15 = QtWidgets.QPushButton(self)
        self.button_15.setFixedSize(50, 50)
        if QtCore.QResource(':/rebuild.png').isValid():
            i = QtGui.QIcon(':/rebuild.png')
            self.button_15.setIcon(i)
        self.button_15.setIconSize(QSize(50, 50))

        self.button_16 = QtWidgets.QPushButton('拷贝权重')
        self.button_17 = QtWidgets.QPushButton('对半拷贝权重')

        self.splitter_2 = QtWidgets.QSplitter()
        self.splitter_2.setFixedHeight(1)
        self.splitter_2.setFrameStyle(1)

        # 第三行
        self.comboBox_1 = QtWidgets.QComboBox()
        self.comboBox_1.addItems(['后期', '交互'])

        self.Label_1 = QtWidgets.QLabel()
        self.Label_1.setText('平滑次数:')
        self.line_edit_3 = QtWidgets.QLineEdit()
        self.line_edit_3.setFixedWidth(50)
        self.line_edit_3.setText('1')
        self.slider_1 = QtWidgets.QSlider(Qt.Horizontal)
        self.slider_1.setMinimum(1)
        self.slider_1.setMaximum(10)

        self.button_18 = QtWidgets.QPushButton('平滑权重')

        self.splitter_3 = QtWidgets.QSplitter()
        self.splitter_3.setFixedHeight(1)
        self.splitter_3.setFrameStyle(1)

        #第四行
        self.button_19 = QtWidgets.QPushButton('选择目标模型:')
        self.line_edit_4 = QtWidgets.QLineEdit()
        self.button_20 = QtWidgets.QPushButton('加载')
        self.button_21 = QtWidgets.QPushButton('选择模型合并权重到目标')
        self.button_22 = QtWidgets.QPushButton('导出权重')
        self.button_23 = QtWidgets.QPushButton('导入权重')

        self.splitter_4 = QtWidgets.QSplitter()
        self.splitter_4.setFixedHeight(1)
        self.splitter_4.setFrameStyle(1)
        # self.checkbox = QtWidgets.QCheckBox('Checkbox')

        #第五行
        self.LisLineButtonSize = [40,50]
        self.button_24 = QtWidgets.QToolButton(self)
        self.button_24.setAutoRaise(True)
        self.button_24.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        self.button_24.setText('选择层次')
        self.button_24.setFixedSize(50, self.LisLineButtonSize[1])
        if QtCore.QResource(':/menuIconSelect.png').isValid():
            i = QtGui.QIcon(':/menuIconSelect.png')
            self.button_24.setIcon(i)
        self.button_24.setIconSize(QSize(30, 30))

        self.button_25 = QtWidgets.QToolButton(self)
        self.button_25.setAutoRaise(True)
        self.button_25.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/CenterPivot.png').isValid():
            i = QtGui.QIcon(':/CenterPivot.png')
            self.button_25.setIcon(i)
        self.button_25.setIconSize(QSize(50, 50))

        self.button_26 = QtWidgets.QToolButton(self)
        self.button_26.setAutoRaise(True)
        self.button_26.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/DeleteHistory.png').isValid():
            i = QtGui.QIcon(':/DeleteHistory.png')
            self.button_26.setIcon(i)
        self.button_26.setIconSize(QSize(50, 50))

        self.button_27 = QtWidgets.QToolButton(self)
        self.button_27.setAutoRaise(True)
        self.button_27.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/FreezeTransform.png').isValid():
            i = QtGui.QIcon(':/FreezeTransform.png')
            self.button_27.setIcon(i)
        self.button_27.setIconSize(QSize(50, 50))

        self.button_28 = QtWidgets.QToolButton(self)
        self.button_28.setAutoRaise(True)
        self.button_28.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/polyDelEdgeVertex.png').isValid():
            i = QtGui.QIcon(':/polyDelEdgeVertex.png')
            self.button_28.setIcon(i)
        self.button_28.setIconSize(QSize(50, 50))

        self.button_29 = QtWidgets.QToolButton(self)
        self.button_29.setAutoRaise(True)
        self.button_29.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/polySplitEdgeRing.png').isValid():
            i = QtGui.QIcon(':/polySplitEdgeRing.png')
            self.button_29.setIcon(i)
        self.button_29.setIconSize(QSize(50, 50))

        self.button_30 = QtWidgets.QToolButton(self)
        self.button_30.setAutoRaise(True)
        self.button_30.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/polyExtrudeFacet.png').isValid():
            i = QtGui.QIcon(':/polyExtrudeFacet.png')
            self.button_30.setIcon(i)
        self.button_30.setIconSize(QSize(50, 50))

        self.button_31 = QtWidgets.QToolButton(self)
        self.button_31.setAutoRaise(True)
        self.button_31.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/locator.png').isValid():
            i = QtGui.QIcon(':/locator.png')
            self.button_31.setIcon(i)
        self.button_31.setIconSize(QSize(50, 50))

        self.button_32 = QtWidgets.QToolButton(self)
        self.button_32.setAutoRaise(True)
        self.button_32.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/cluster.png').isValid():
            i = QtGui.QIcon(':/cluster.png')
            self.button_32.setIcon(i)
        self.button_32.setIconSize(QSize(50, 50))

        self.button_33 = QtWidgets.QToolButton(self)
        self.button_33.setAutoRaise(True)
        self.button_33.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        self.button_33.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        self.button_33.setText('S_V')
        if QtCore.QResource(':/kinJoint.png').isValid():
            i = QtGui.QIcon(':/kinJoint.png')
            self.button_33.setIcon(i)
        self.button_33.setIconSize(QSize(50, 50))

        self.button_34 = QtWidgets.QToolButton(self)
        self.button_34.setAutoRaise(True)
        self.button_34.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        self.button_34.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
        self.button_34.setText('S_V')
        if QtCore.QResource(':/channelBoxUseManips.png').isValid():
            i = QtGui.QIcon(':/channelBoxUseManips.png')
            self.button_34.setIcon(i)
        self.button_34.setIconSize(QSize(50, 50))

        self.button_35 = QtWidgets.QToolButton(self)
        self.button_35.setAutoRaise(True)
        self.button_35.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/blendShapeEditor.png').isValid():
            i = QtGui.QIcon(':/blendShapeEditor.png')
            self.button_35.setIcon(i)
        self.button_35.setIconSize(QSize(50, 50))

        self.button_36 = QtWidgets.QToolButton(self)
        self.button_36.setAutoRaise(True)
        self.button_36.setFixedSize(self.LisLineButtonSize[0], self.LisLineButtonSize[1])
        if QtCore.QResource(':/polyRetopo.png').isValid():
            i = QtGui.QIcon(':/polyRetopo.png')
            self.button_36.setIcon(i)
        self.button_36.setIconSize(QSize(50, 50))

        self.splitter_5 = QtWidgets.QSplitter()
        self.splitter_5.setFixedHeight(1)
        self.splitter_5.setFrameStyle(1)

        # 第六行
        self.button_37 = QtWidgets.QPushButton('为当前选择模型归一化权重')
        self.button_38 = QtWidgets.QPushButton('为当前选择骨骼修复模型移动过远出现抖动的情况(先选跟骨骼)')
        self.button_39 = QtWidgets.QPushButton('选择根骨骼撤回当前修复')


        self.splitter_6 = QtWidgets.QSplitter()
        self.splitter_6.setFixedHeight(1)
        self.splitter_6.setFrameStyle(1)

    def create_layouts(self):
        self.central_widget = QtWidgets.QWidget(self)
        self.setCentralWidget(self.central_widget)

        main_layout = QtWidgets.QVBoxLayout(self.central_widget)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(1)

        # 第一行
        h_Box_layout_1 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_1)
        h_Box_layout_1.setSpacing(1)

        h_Box_layout_2 = QtWidgets.QHBoxLayout(self)
        h_Box_layout_1.addLayout(h_Box_layout_2)

        h_Box_layout_3 = QtWidgets.QHBoxLayout(self)
        h_Box_layout_2.addLayout(h_Box_layout_3)
        h_Box_layout_3.addWidget(self.button_1)
        h_Box_layout_3.addWidget(self.line_edit_1)
        h_Box_layout_3.addWidget(self.button_2)

        # h_Box_layout_1.addStretch(1)

        h_Box_layout_4 = QtWidgets.QHBoxLayout(self)
        h_Box_layout_2.addLayout(h_Box_layout_4)
        h_Box_layout_4.addWidget(self.button_3)
        h_Box_layout_4.addWidget(self.line_edit_2)
        h_Box_layout_4.addWidget(self.button_4)

        h_Box_layout_5 = QtWidgets.QHBoxLayout(self)
        h_Box_layout_2.addLayout(h_Box_layout_5)
        h_Box_layout_5.addWidget(self.button_5)

        main_layout.addWidget(self.splitter_1)
        # 第二行
        h_Box_layout_6 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_6)
        h_Box_layout_6.setSpacing(1)

        q_grid_layout_1 = QtWidgets.QGridLayout(self)
        h_Box_layout_6.addLayout(q_grid_layout_1)
        q_grid_layout_1.setColumnStretch(1, 0)
        q_grid_layout_1.addWidget(self.button_6)
        q_grid_layout_1.addWidget(self.button_7)
        q_grid_layout_1.addWidget(self.button_8)

        h_Box_layout_7 = QtWidgets.QHBoxLayout(self)
        h_Box_layout_6.addLayout(h_Box_layout_7)
        h_Box_layout_7.addWidget(self.button_9)
        h_Box_layout_7.addWidget(self.button_10)
        h_Box_layout_7.addWidget(self.button_11)
        h_Box_layout_7.addWidget(self.button_12)
        h_Box_layout_7.addWidget(self.button_13)
        h_Box_layout_7.addWidget(self.button_14)
        h_Box_layout_7.addWidget(self.button_15)

        v_box_layout_1 = QtWidgets.QVBoxLayout(self)
        h_Box_layout_6.addLayout(v_box_layout_1)
        v_box_layout_1.addWidget(self.button_16)
        v_box_layout_1.addWidget(self.button_17)

        main_layout.addWidget(self.splitter_2)
        # 第三行
        h_Box_layout_8 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_8)
        h_Box_layout_8.addWidget(self.comboBox_1)

        h_Box_layout_9 = QtWidgets.QHBoxLayout(self)
        h_Box_layout_8.addLayout(h_Box_layout_9)
        h_Box_layout_9.addWidget(self.Label_1)
        h_Box_layout_9.addWidget(self.line_edit_3)
        h_Box_layout_9.addWidget(self.slider_1)

        h_Box_layout_8.addWidget(self.button_18)

        main_layout.addWidget(self.splitter_3)
        # 第四行
        h_Box_layout_10 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_10)
        h_Box_layout_10.addWidget(self.button_19)
        h_Box_layout_10.addWidget(self.line_edit_4)
        h_Box_layout_10.addWidget(self.button_20)
        h_Box_layout_10.addWidget(self.button_21)
        h_Box_layout_10.addWidget(self.button_22)
        h_Box_layout_10.addWidget(self.button_23)

        main_layout.addWidget(self.splitter_4)

        # 第五行
        h_Box_layout_11 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_11)
        h_Box_layout_11.addWidget(self.button_24)
        h_Box_layout_11.addWidget(self.button_25)
        h_Box_layout_11.addWidget(self.button_26)
        h_Box_layout_11.addWidget(self.button_27)
        h_Box_layout_11.addWidget(self.button_28)
        h_Box_layout_11.addWidget(self.button_29)
        h_Box_layout_11.addWidget(self.button_30)
        h_Box_layout_11.addWidget(self.button_31)
        h_Box_layout_11.addWidget(self.button_32)
        h_Box_layout_11.addWidget(self.button_33)
        h_Box_layout_11.addWidget(self.button_34)
        h_Box_layout_11.addWidget(self.button_35)
        h_Box_layout_11.addWidget(self.button_36)
        main_layout.addStretch(1)
        main_layout.addWidget(self.splitter_5)

        # 第六行
        h_Box_layout_12 = QtWidgets.QHBoxLayout(self)
        main_layout.addLayout(h_Box_layout_12)
        h_Box_layout_12.addWidget(self.button_37)
        h_Box_layout_12.addWidget(self.button_38)
        h_Box_layout_12.addWidget(self.button_39)


        main_layout.addWidget(self.splitter_6)
        # 置顶

    def create_connect(self):
        pass

window = Window()
if __name__ == '__main__':
    window.show()