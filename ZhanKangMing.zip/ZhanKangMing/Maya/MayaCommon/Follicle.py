#coding=gbk
import pymel.core as pm
import maya.cmds as cmds
import maya.mel as mel
class ZKM_FollicleClass:
    # ë��Լ��
    def ZKM_FollicleConstraint(self,model, sel, keep):
        cmds.undoInfo(ock=1)
        cmds.select(cl=1)
        if not cmds.objExists('AllFollicle_Grp'):
            cmds.group(em=1, n='AllFollicle_Grp')
        shape = cmds.listRelatives(model, s=1)
        TypeMesh = cmds.ls(shape[0], type='mesh')
        if TypeMesh:
            cmds.createNode('closestPointOnMesh', n=("cpom"))
            cmds.connectAttr((shape[0] + '.outMesh'), ('cpom' + '.inMesh'), f=1)
        TypeNurbs = cmds.ls(shape[0], type='nurbsSurface')
        if TypeNurbs:
            cmds.createNode('closestPointOnSurface', n=("cpom"))
            cmds.connectAttr((shape[0] + '.worldSpace[0]'), ('cpom' + '.inputSurface'), f=1)
        cmds.spaceLocator(p=(0, 0, 0), n=("Loc"))
        for i in range(0, len(sel)):
            cmds.delete(cmds.pointConstraint(sel[i], "Loc", weight=1, offset=(0, 0, 0)))
            pos = cmds.xform(("Loc"), q=1, a=1, ws=1, t=1)
            cmds.setAttr(("cpom" + ".inPositionX"), pos[0])
            cmds.setAttr(("cpom" + ".inPositionY"), pos[1])
            cmds.setAttr(("cpom" + ".inPositionZ"), pos[2])
            u = float(cmds.getAttr("cpom" + ".parameterU"))
            v = float(cmds.getAttr("cpom" + ".parameterV"))
            cmds.createNode('follicle', n=(sel[i] + "_follicleShape"))
            if TypeMesh:
                shape = cmds.listRelatives(model, s=1, type='mesh')
                cmds.connectAttr((shape[0] + ".outMesh"), (sel[i] + "_follicleShape" + ".inputMesh"), f=1)
                cmds.connectAttr((shape[0] + ".worldMatrix[0]"),
                                 (sel[i] + "_follicleShape" + ".inputWorldMatrix"), f=1)
            if TypeNurbs:
                shape = cmds.listRelatives(model, s=1, type='nurbsSurface')
                cmds.connectAttr((shape[0] + '.worldSpace[0]'), (sel[i] + '_follicleShape' + '.inputSurface'), f=1)
                cmds.connectAttr((shape[0] + '.worldMatrix[0]'), (sel[i] + '_follicleShape' + '.inputWorldMatrix'),
                                 f=1)
            cmds.connectAttr((sel[i] + "_follicleShape" + ".outTranslate"), (sel[i] + "_follicle" + ".translate"),
                             f=1)
            cmds.connectAttr((sel[i] + "_follicleShape" + ".outRotate"), (sel[i] + "_follicle" + ".rotate"), f=1)
            cmds.setAttr((sel[i] + "_follicleShape" + ".parameterU"), u)
            cmds.setAttr((sel[i] + "_follicleShape" + ".parameterV"), v)
            if keep == True:
                if not i == 'FaceLoc_head_loc_M':
                    cmds.parentConstraint((sel[i] + "_follicle"), sel[i], mo=1, weight=1)
            else:
                cmds.parentConstraint((sel[i] + "_follicle"), sel[i], weight=1)
            if cmds.objExists('AllFollicle_Grp'):
                cmds.parent((sel[i] + "_follicle"), 'AllFollicle_Grp')
        cmds.delete("Loc")
        cmds.delete("cpom")
        cmds.undoInfo(cck=1)
        # ZKM_FollicleClass().ZKM_FollicleConstraint('bace_bs_Mesh',['nurbsCircle1','nurbsCircle2'],'Ture')
