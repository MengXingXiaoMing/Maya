#coding=gbk
print('aaaaaaaaaa')